-- phpMyAdmin SQL Dump
-- version 4.7.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 13, 2023 at 03:54 AM
-- Server version: 10.1.22-MariaDB
-- PHP Version: 7.1.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `meepan`
--

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `is_correct` tinyint(1) NOT NULL DEFAULT '0',
  `coption` text NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `options`
--

INSERT INTO `options` (`id`, `question_number`, `is_correct`, `coption`, `type`) VALUES
(1, 1, 0, 'Alengka Kingdom', 'Yudistira'),
(2, 1, 0, 'Asmaka Kingdom', 'Yudistira'),
(3, 1, 1, 'The Kingdom of Amarta', 'Yudistira'),
(4, 2, 0, 'Sudarshan Chakra', 'Yudistira'),
(5, 2, 1, 'Letter of Jamus Kalimasada', 'Yudistira'),
(6, 2, 0, 'Brahmasta', 'Yudistira'),
(7, 3, 0, 'Brahmasta', 'Yudistira'),
(8, 3, 1, 'Book', 'Yudistira'),
(9, 3, 0, 'Pistol', 'Yudistira'),
(10, 4, 1, 'Protagonist', 'Yudistira'),
(11, 4, 0, 'Antagonist', 'Yudistira'),
(12, 4, 0, 'Tritagonist characters', 'Yudistira'),
(13, 5, 1, 'Holy, Ambeg brahmin', 'Yudistira'),
(14, 5, 0, 'Angry', 'Yudistira'),
(15, 5, 0, 'Like riots', 'Yudistira'),
(16, 6, 0, 'Kris', 'Yudistira'),
(17, 6, 0, 'Arrow', 'Yudistira'),
(18, 6, 1, 'Book', 'Yudistira'),
(19, 7, 0, 'Permadi, Dosomuko, Basukarno', 'Yudistira'),
(20, 7, 1, 'Puntadewa, Dwijakangka, Bunatali', 'Yudistira'),
(21, 7, 0, 'Ciptaning, kaunteya, Bharatasresta', 'Yudistira'),
(22, 8, 1, 'Telling the enemies of Pandavas attempts to steal Kalimasada', 'Yudistira'),
(23, 8, 0, 'Tells enemies attempt to seize the royal Pandava Yudhistira', 'Yudistira'),
(24, 8, 0, 'Tell enemies attempt to beat Yudhisthira Pandavas', 'Yudistira'),
(25, 9, 0, 'Krisna', 'Yudistira'),
(26, 9, 0, 'Arjuna', 'Yudistira'),
(27, 9, 1, 'Yudhisthira', 'Yudistira'),
(28, 10, 1, 'Bhima, Arjuna, Nakula, and Sahadeva', 'Yudistira'),
(29, 10, 0, 'Karna, Pandu, Dretarastra, and Bhishma', 'Yudistira'),
(30, 10, 0, 'Amba, Subhadra, Vidura, and Vikarna', 'Yudistira'),
(31, 1, 1, 'Werkudara', 'Bima'),
(32, 1, 0, 'Sadewa', 'Bima'),
(33, 1, 0, 'Dushasana', 'Bima'),
(34, 2, 0, 'Anarchist', 'Bima'),
(35, 2, 0, 'Naughty', 'Bima'),
(36, 2, 1, 'Knight', 'Bima'),
(37, 3, 0, 'Loyal to partner', 'Bima'),
(38, 3, 0, 'Likes to keep promises', 'Bima'),
(39, 3, 1, 'Dislikes small talk', 'Bima'),
(40, 4, 0, '3', 'Bima'),
(41, 4, 1, '2', 'Bima'),
(42, 4, 0, '4', 'Bima'),
(43, 5, 0, 'Karna and Jamus Kalimasada', 'Bima'),
(44, 5, 1, 'Pancanaka Nails and Gad Rujapala', 'Bima'),
(45, 5, 0, 'Pasopati Arrows and Gandiwa Bows', 'Bima'),
(46, 6, 1, 'Black thumb nails, curved Long down and sharp', 'Bima'),
(47, 6, 0, 'Pinky nail black, curved Long down and sharp', 'Bima'),
(48, 6, 0, 'Middle finger nails black, curved Long down and sharp', 'Bima'),
(49, 7, 0, '7 times sharp arrow pasopati', 'Bima'),
(50, 7, 0, 'Like being hit by a bow arrow', 'Bima'),
(51, 7, 1, 'Sharp 7 times razor sharp', 'Bima'),
(52, 8, 0, 'Arjuna', 'Bima'),
(53, 8, 1, 'Duryudana', 'Bima'),
(54, 8, 0, 'Destarastra', 'Bima'),
(55, 9, 1, 'Breaking Duryodhana\'s thighs Breaking Duryodhana\'s', 'Bima'),
(56, 9, 0, 'Hands', 'Bima'),
(57, 9, 0, 'Breaking Legs', 'Bima'),
(58, 10, 0, 'Hand', 'Bima'),
(59, 10, 0, 'Feet', 'Bima'),
(60, 10, 1, 'Thigh', 'Bima'),
(61, 1, 0, 'Wandering, Fighting and Learning', 'Arjuna'),
(62, 1, 0, 'Wandering, Fighting, and Hunting', 'Arjuna'),
(63, 1, 1, 'Wandering, and Meditating, and Learning ', 'Arjuna'),
(64, 2, 0, '4', 'Arjuna'),
(65, 2, 0, '3', 'Arjuna'),
(66, 2, 1, '2', 'Arjuna'),
(67, 3, 1, 'Niwatacaraka', 'Arjuna'),
(68, 3, 0, 'Gatotkaca', 'Arjuna'),
(69, 3, 0, 'Krisna', 'Arjuna'),
(70, 4, 0, 'Niwatacaraka', 'Arjuna'),
(71, 4, 1, 'Gatotkaca', 'Arjuna'),
(72, 4, 0, 'Krisna', 'Arjuna'),
(73, 5, 0, 'Nail Pancanaka and Gas Rujapala', 'Arjuna'),
(74, 5, 1, 'Pasopati Arrow and Gandiva Bow', 'Arjuna'),
(75, 5, 0, 'Pasopati Arrow and Gada Rujapala', 'Arjuna'),
(76, 6, 0, 'Sadewa', 'Arjuna'),
(77, 6, 0, 'Gatotkaca', 'Arjuna'),
(78, 6, 1, 'Krishna', 'Arjuna'),
(79, 7, 0, 'Bhagavad Gita', 'Arjuna'),
(80, 7, 0, 'Bhagavad Gita', 'Arjuna'),
(81, 7, 1, 'Bhagavad Gita', 'Arjuna'),
(82, 8, 1, 'Before the Bhagavadgita', 'Arjuna'),
(83, 8, 0, 'After the Bhagavadgita', 'Arjuna'),
(84, 8, 0, 'Before the war with Nakula', 'Arjuna'),
(85, 9, 1, 'Parantapa', 'Arjuna'),
(86, 9, 0, 'Basudewa', 'Arjuna'),
(87, 9, 0, 'Gatotkaca', 'Arjuna'),
(88, 10, 0, 'Because he likes to help others', 'Arjuna'),
(89, 10, 1, 'Because any kind of enemy will surely be conquered', 'Arjuna'),
(90, 10, 0, 'Because of his handsome face and dashing body', 'Arjuna'),
(91, 1, 0, 'Cute, Grumpy, and liar', 'Nakula'),
(92, 1, 1, 'Honest, loyal, respectful and devoted to his parents and siblings', 'Nakula'),
(93, 1, 0, 'Lazy, Cowardly, stupid, and honest', 'Nakula'),
(94, 2, 0, 'Arjuna', 'Nakula'),
(95, 2, 0, 'Bima', 'Nakula'),
(96, 2, 1, 'Sadewa', 'Nakula'),
(97, 3, 1, 'To boast of his good looks', 'Nakula'),
(98, 3, 0, 'To play girl', 'Nakula'),
(99, 3, 0, 'To lie', 'Nakula'),
(100, 4, 1, 'Horse care and astrology', 'Nakula'),
(101, 4, 0, 'Reliable Stealing', 'Nakula'),
(102, 4, 0, 'Great meat cutters', 'Nakula'),
(103, 5, 0, 'the best son in the world', 'Nakula'),
(104, 5, 1, 'the most handsome husband in the world', 'Nakula'),
(105, 5, 0, 'the prettiest man in the world', 'Nakula'),
(106, 6, 0, 'Gada Rujak Pala', 'Nakula'),
(107, 6, 0, 'Panah Pasopati', 'Nakula'),
(108, 6, 1, 'Banyu Kahuripan', 'Nakula'),
(109, 7, 0, 'Beauty Water', 'Nakula'),
(110, 7, 1, 'Water of Life', 'Nakula'),
(111, 7, 0, 'Eternal Water', 'Nakula'),
(112, 8, 0, 'Bathara Ismaya', 'Nakula'),
(113, 8, 0, 'Bathara Wisnu', 'Nakula'),
(114, 8, 1, 'Bathara Indra', 'Nakula'),
(115, 9, 1, 'Ajian Pranawajati', 'Nakula'),
(116, 9, 0, 'Ajian Pancasona', 'Nakula'),
(117, 9, 0, 'Ajian Bandungbandawasa', 'Nakula'),
(118, 10, 0, 'Ksatria', 'Nakula'),
(119, 10, 1, 'Unable to forget what he knows', 'Nakula'),
(120, 10, 0, 'Strong and awesome', 'Nakula'),
(121, 1, 1, 'Honest, loyal, obedient to parents', 'Sadewa'),
(122, 1, 0, 'Honest, loyal, respectful and devoted to his parents and siblings', 'Sadewa'),
(123, 1, 0, 'Lazy, Cowardly, stupid, and honest', 'Sadewa'),
(124, 2, 0, 'Karna', 'Sadewa'),
(125, 2, 0, 'Arjuna', 'Sadewa'),
(126, 2, 1, 'Nakula ', 'Sadewa'),
(127, 3, 1, 'In terms of astrology or astronomy, and raising cows', 'Sadewa'),
(128, 3, 0, 'In search of female attention', 'Sadewa'),
(129, 3, 0, 'In killing his enemies', 'Sadewa'),
(130, 4, 0, 'Madukara', 'Sadewa'),
(131, 4, 0, 'Astinapura', 'Sadewa'),
(132, 4, 1, 'Bumiretawu', 'Sadewa'),
(133, 5, 1, 'Purnamajati', 'Sadewa'),
(134, 5, 0, 'Pranawajati', 'Sadewa'),
(135, 5, 0, 'Pancasona', 'Sadewa'),
(136, 6, 1, 'Remember events that they know and experience', 'Sadewa'),
(137, 6, 0, 'Unable to forget what he knows', 'Sadewa'),
(138, 6, 0, 'Unable to forget what he knows', 'Sadewa'),
(139, 7, 0, 'Bathara Indra', 'Sadewa'),
(140, 7, 1, 'Ditya Sapulebu', 'Sadewa'),
(141, 7, 0, 'Bathara Guru', 'Sadewa'),
(142, 8, 0, 'Wirakrama', 'Sadewa'),
(143, 8, 1, 'Tantripala', 'Sadewa'),
(144, 8, 0, 'Arjuna', 'Sadewa'),
(145, 9, 0, 'Skilled in horseback riding', 'Sadewa'),
(146, 9, 1, 'Horse care and astrology', 'Sadewa'),
(147, 9, 0, 'Reliable Stealing', 'Sadewa'),
(148, 10, 1, 'Intelligence is far abovestudents Drona\'s other', 'Sadewa'),
(149, 10, 0, 'Intelligence is far abovestudents Bathara Guru\'s other', 'Sadewa'),
(150, 10, 0, 'Intelligence is far abovestudents Kurawa\'s other', 'Sadewa'),
(151, 1, 0, 'Aku maos koran', 'Krama'),
(152, 1, 0, 'Bapak mangan soto', 'Krama'),
(153, 1, 1, 'Ibuk tindak peken', 'Krama'),
(154, 2, 1, 'Bapak badhe dhahar soto kaliyan ibuk wonten warung', 'Krama'),
(155, 2, 0, 'Aku didhawuhi bapak dhahar soto', 'Krama'),
(156, 2, 0, 'Adek sinau ning kamar karo aku', 'Krama'),
(157, 3, 0, 'Ibuk lungo pasar karo bulik', 'Krama'),
(158, 3, 0, 'Aku tuku endog ning warung', 'Krama'),
(159, 3, 1, 'Bapak ngendika dhateng Paklik badhe tindak Semarang', 'Krama'),
(160, 4, 0, 'Soca', 'Krama'),
(161, 4, 0, 'Lathi', 'Krama'),
(162, 4, 1, 'Asta', 'Krama'),
(163, 5, 0, 'Soca', 'Krama'),
(164, 5, 1, 'Grana', 'Krama'),
(165, 5, 0, 'Asta', 'Krama'),
(166, 1, 0, '1', 'Ngoko'),
(167, 1, 1, '2', 'Ngoko'),
(168, 1, 0, '3', 'Ngoko'),
(169, 2, 0, 'Sare ', 'Ngoko'),
(170, 2, 0, 'Siles ', 'Ngoko'),
(171, 2, 1, 'Turu', 'Ngoko'),
(172, 3, 1, 'Bapak gak turu?', 'Ngoko'),
(173, 3, 0, 'Bapak mboten sare?', 'Ngoko'),
(174, 3, 0, 'Raturu pak?', 'Ngoko'),
(175, 4, 0, 'Kon lungo rindi?', 'Ngoko'),
(176, 4, 0, 'Awakmu metu rindi?', 'Ngoko'),
(177, 4, 1, 'Sampeyan lungo teng pundi?', 'Ngoko'),
(178, 5, 0, 'Kon', 'Ngoko'),
(179, 5, 1, 'Sampeyan', 'Ngoko'),
(180, 5, 0, 'Awakmu', 'Ngoko');

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `id` int(11) NOT NULL,
  `question_number` int(11) NOT NULL,
  `question_text` text NOT NULL,
  `type` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`id`, `question_number`, `question_text`, `type`) VALUES
(1, 1, 'What kingdom is the puppet character Yudistira capable of leading ?', 'Yudistira'),
(2, 2, 'What weapons does the Yudhisthira puppet have ?', 'Yudistira'),
(3, 3, 'What form is Yudhisthira\'s puppet weapon ?', 'Yudistira'),
(4, 4, 'What is the character of the Yudistira puppet ? ', 'Yudistira'),
(5, 5, 'What is a character ?', 'Yudistira'),
(6, 6, 'What objects are sacred by the kingdom of Amarta ?', 'Yudistira'),
(7, 7, 'What is another name for wayang Yudhisthira?', 'Yudistira'),
(8, 8, 'What story is told in the Padalangan story ?', 'Yudistira'),
(9, 9, 'Who is the leader of the Pandavas ?', 'Yudistira'),
(10, 10, 'King Yudistira has 4 younger siblings. Who is it ?', 'Yudistira'),
(11, 1, 'What is another name for the Bima puppet ?', 'Bima'),
(12, 2, 'What is the character of the Bima puppet ?', 'Bima'),
(13, 3, 'What does it mean for Bima to be loyal to one attitude ?', 'Bima'),
(14, 4, 'How many weapons does the Bima puppet have ?', 'Bima'),
(15, 5, 'What are the weapons owned by wayang Bima ?', 'Bima'),
(16, 6, 'What is the shape of Pancanaka\'s nails ?', 'Bima'),
(17, 7, 'How sharp are Pancanaka\'s nails ?', 'Bima'),
(18, 8, 'Mace Raju Nutmeg weapon used to kill who ?', 'Bima'),
(19, 9, 'What oath did Bima take in the war against Duryodhana ?', 'Bima'),
(20, 10, 'Bhima kills Duryodhana; he points his club at Duryodhana\'s body, namely ?', 'Bima'),
(21, 1, 'In the puppet world Arjuna is described as a knight who likes ?', 'Arjuna'),
(22, 2, 'How many weapons does the wayang Arjuna have ?', 'Arjuna'),
(23, 3, 'Who did Arjuna use the pasopati arrow to kill ?', 'Arjuna'),
(24, 4, 'Who was the double bow used to kill ?', 'Arjuna'),
(25, 5, 'What weapons does Arjuna have ?', 'Arjuna'),
(26, 6, 'Who are Arjuna\'s closest friends in wayang ?', 'Arjuna'),
(27, 7, 'Do you know what advice Krishna gave to Arjuna ?', 'Arjuna'),
(28, 8, 'When was the discourse delivered ?', 'Arjuna'),
(29, 9, 'What nickname was given to Arjuna ?', 'Arjuna'),
(30, 10, 'Why was Arjuna given the nickname Dananjaya ?', 'Arjuna'),
(31, 1, 'What is the character of the Nakula puppet ?', 'Nakula'),
(32, 2, 'Nakula is the twin brother of ?', 'Nakula'),
(33, 3, 'What bad qualities does Nakula have ?', 'Nakula'),
(34, 4, 'What special abilities does Nakula have ?', 'Nakula'),
(35, 5, 'According to Draupadi Nakula is ?', 'Nakula'),
(36, 6, 'What weapons does Nakula have ?', 'Nakula'),
(37, 7, 'What is the meaning of Banyu Kahuripan ?', 'Nakula'),
(38, 8, 'Banyu Kahuripan is a gift from ?', 'Nakula'),
(39, 9, 'Nakula also has a spell named ?', 'Nakula'),
(40, 10, 'The spell that Nakula possesses can make him become ?', 'Nakula'),
(41, 1, 'What is the character of the puppet Sadewa.', 'Sadewa'),
(42, 2, 'Sahadeva is a twin of ?', 'Sadewa'),
(43, 3, 'What skills does Sahadeva have ?', 'Sadewa'),
(44, 4, 'Raden Sadewa is a warrior from ?', 'Sadewa'),
(45, 5, 'Raden Sadewa has a spell called ?', 'Sadewa'),
(46, 6, 'The magic that Sahadeva has can make him become ?', 'Sadewa'),
(47, 7, 'The prayer that Sahadeva had was a gift from ?', 'Sadewa'),
(48, 8, 'When you lose playing dice against Kurawa Sahadeva, you choose to play a cowherd named ?', 'Sadewa'),
(49, 9, 'What is Sahadeva also good at ?', 'Sadewa'),
(50, 10, 'In terms of astrology and astronomy, Sahadeva\'s intelligence far exceeds whom ?', 'Sadewa'),
(51, 1, 'Which of the following sentences is correct ?', 'Krama'),
(52, 2, 'Which of the following sentences is correct ?', 'Krama'),
(53, 3, 'Which of the following sentences is correct ?', 'Krama'),
(54, 4, 'Basa Krama (the Krama language) of the word \'hand\' is...', 'Krama'),
(55, 5, 'Basa Krama (the Krama language) of the word \'nose\' is...', 'Krama'),
(56, 1, 'How many variants of basa Ngoko are in the Javanese language ?', 'Ngoko'),
(57, 2, 'Basa ngoko lugu in the Javanese language from the word \'sleep\' is...', 'Ngoko'),
(58, 3, 'Which the Ngoko lugu?s following sentence is correct ?', 'Ngoko'),
(59, 4, 'Which the Ngoko Alus\'s following sentence is correct ?', 'Ngoko'),
(60, 5, 'Basa Ngoko Alus in the Javanese language from the word \'I\'m\' is...', 'Ngoko');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `age` int(11) NOT NULL,
  `gender` enum('male','female') NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `age`, `gender`, `password`) VALUES
(9, 'admin', 'admin@gmail.com', 12, 'male', '$2y$10$nLuwngoQq9xgOyB.ucPBMe29ms7jsL0AIPpd0opyDUHFkS.8B6b9.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `questions`
--
ALTER TABLE `questions`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `questions`
--
ALTER TABLE `questions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=61;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
